#include<stdlib.h>
unsigned int i,j;
//shift functions
	void s_left(int array[4][4]);
    void s_right(int array[4][4]);
    void s_up(int array[4][4]);
    void s_down(int array[4][4]);
//add functions  
    void a_left(int array[4][4]);
    void a_right(int array[4][4]);
    void a_up(int array[4][4]);
    void a_down(int array[4][4]);

    bool win_check(int array[4][4]);
    bool lose_check(int array[4][4]);
    void new_val(int array[4][4]);
    

void s_left(int array[4][4])
    {
        for(i=0;i<4;i++)
        {for(j=0;j<4;j++){
            if(array[i][2]==0){array[i][2]=array[i][3];array[i][3]=0;}
            if(array[i][1]==0){array[i][1]=array[i][2];array[i][2]=0;}
            if(array[i][0]==0){array[i][0]=array[i][1];array[i][1]=0;}
        }
        }
    }
    void s_right(int array[4][4])
    {
     for(i=0;i<4;i++)
        {for(j=0;j<4;j++){
            if(array[i][1]==0){array[i][1]=array[i][0];array[i][0]=0;}
            if(array[i][2]==0){array[i][2]=array[i][1];array[i][1]=0;}
            if(array[i][3]==0){array[i][3]=array[i][2];array[i][2]=0;}
        }
    }}
    void s_up(int array[4][4])
     {
      for(j=0;j<4;j++)
        {for(i=0;i<4;i++){
            if(array[2][j]==0){array[2][j]=array[3][j];array[3][j]=0;}
            if(array[1][j]==0){array[1][j]=array[2][j];array[2][j]=0;}
            if(array[0][j]==0){array[0][j]=array[1][j];array[1][j]=0;}
        }
        }
    }
    void s_down(int array[4][4])
    {
     for(j=0;j<4;j++)
        {for(i=0;i<4;i++){
            if(array[1][j]==0){array[1][j]=array[0][j];array[0][j]=0;}
            if(array[2][j]==0){array[2][j]=array[1][j];array[1][j]=0;}
            if(array[3][j]==0){array[3][j]=array[2][j];array[2][j]=0;}
        }}
    }

    void a_left(int array[4][4])
    {   for(i=0;i<4;i++)
        {for(j=0;j<3;j++)
            { if(array[i][j]==array[i][j+1]){array[i][j]=array[i][j]+array[i][j];array[i][j+1]=0;}
            }}}
    void a_right(int array[4][4])
    {
        for(i=0;i<4;i++)
        {for(j=3;j>0;j--)
        {
           if(array[i][j]==array[i][j-1]){array[i][j]=array[i][j]+array[i][j];array[i][j-1]=0;}
        }
        }
    }
    void a_up(int array[4][4])
    {
        for(i=0;i<4;i++)
        {
            for(j=0;j<4;j++)
            {
                if(array[i][j]==array[i+1][j]){array[i][j]=array[i][j]+array[i][j];array[i+1][j]=0;}
            }
        }
    }
    void a_down(int array[4][4])
     {
        for(i=3;i>0;i--)
        {for(j=0;j<4;j++)
        {
           if(array[i][j]==array[i-1][j]){array[i][j]=array[i][j]+array[i][j];array[i-1][j]=0;}
        }
        }
    }
   bool win_check(int array[4][4])
    {
         for(i=0;i<4;i++)
        {for(j=0;j<4;j++)
            {if(array[i][j]==2048)
            { return 1;
                }}}
            return 0;
    }
    bool lose_check(int array[4][4])
    {
         for(i=0;i<4;i++)
        {for(j=0;j<4;j++)
            {if(array[i][j]==array[i+1][j]||array[i][j]==array[i][j+1]||array[i][j]==0)
            {
                return 0;
                }}}
            return 1;
    }
    void new_val(int array[4][4])
    {
    for(i=0;i<4;i++)
    {for(j=0;j<4;j++)
        {if(array[i][j]==0)
            {array[i][j]=(rand()%2)*2;}
        }}}

		 void clear(int array[4][4])
			 {
         for(i=0;i<4;i++)
        {for(j=0;j<4;j++)
		 {array[i][j]=0;}}}
