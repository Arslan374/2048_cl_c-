#pragma once

#include "win.h"
#include "lose.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
#include "2048.h"
int a[4][4]={0};

namespace myproject {

	/// <summary>
	/// Summary for game1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class game1 : public System::Windows::Forms::Form
	{
	public:
		game1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~game1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::Button^  button1;

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(game1::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::LightGray;
			this->label1->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(18, 20);
			this->label1->MaximumSize = System::Drawing::Size(85, 50);
			this->label1->MinimumSize = System::Drawing::Size(85, 50);
			this->label1->Name = L"label1";
			this->label1->Padding = System::Windows::Forms::Padding(6);
			this->label1->Size = System::Drawing::Size(85, 50);
			this->label1->TabIndex = 0;
			this->label1->Text = L"****";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::LightGray;
			this->label2->Cursor = System::Windows::Forms::Cursors::PanNorth;
			this->label2->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(145, 20);
			this->label2->MaximumSize = System::Drawing::Size(85, 50);
			this->label2->MinimumSize = System::Drawing::Size(85, 50);
			this->label2->Name = L"label2";
			this->label2->Padding = System::Windows::Forms::Padding(6);
			this->label2->Size = System::Drawing::Size(85, 50);
			this->label2->TabIndex = 1;
			this->label2->Text = L"****";
			this->label2->Click += gcnew System::EventHandler(this, &game1::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::LightGray;
			this->label3->Cursor = System::Windows::Forms::Cursors::PanNorth;
			this->label3->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(272, 20);
			this->label3->MaximumSize = System::Drawing::Size(85, 50);
			this->label3->MinimumSize = System::Drawing::Size(85, 50);
			this->label3->Name = L"label3";
			this->label3->Padding = System::Windows::Forms::Padding(6);
			this->label3->Size = System::Drawing::Size(85, 50);
			this->label3->TabIndex = 2;
			this->label3->Text = L"****";
			this->label3->Click += gcnew System::EventHandler(this, &game1::label3_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::LightGray;
			this->label4->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(399, 20);
			this->label4->MaximumSize = System::Drawing::Size(85, 50);
			this->label4->MinimumSize = System::Drawing::Size(85, 50);
			this->label4->Name = L"label4";
			this->label4->Padding = System::Windows::Forms::Padding(6);
			this->label4->Size = System::Drawing::Size(85, 50);
			this->label4->TabIndex = 3;
			this->label4->Text = L"****";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::LightGray;
			this->label5->Cursor = System::Windows::Forms::Cursors::PanWest;
			this->label5->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(18, 84);
			this->label5->MaximumSize = System::Drawing::Size(85, 50);
			this->label5->MinimumSize = System::Drawing::Size(85, 50);
			this->label5->Name = L"label5";
			this->label5->Padding = System::Windows::Forms::Padding(6);
			this->label5->Size = System::Drawing::Size(85, 50);
			this->label5->TabIndex = 4;
			this->label5->Text = L"****";
			this->label5->Click += gcnew System::EventHandler(this, &game1::label5_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::LightGray;
			this->label6->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label6->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(145, 84);
			this->label6->MaximumSize = System::Drawing::Size(85, 50);
			this->label6->MinimumSize = System::Drawing::Size(85, 50);
			this->label6->Name = L"label6";
			this->label6->Padding = System::Windows::Forms::Padding(6);
			this->label6->Size = System::Drawing::Size(85, 50);
			this->label6->TabIndex = 5;
			this->label6->Text = L"****";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::LightGray;
			this->label7->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(272, 84);
			this->label7->MaximumSize = System::Drawing::Size(85, 50);
			this->label7->MinimumSize = System::Drawing::Size(85, 50);
			this->label7->Name = L"label7";
			this->label7->Padding = System::Windows::Forms::Padding(6);
			this->label7->Size = System::Drawing::Size(85, 50);
			this->label7->TabIndex = 6;
			this->label7->Text = L"****";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::LightGray;
			this->label8->Cursor = System::Windows::Forms::Cursors::PanEast;
			this->label8->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label8->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(399, 84);
			this->label8->MaximumSize = System::Drawing::Size(85, 50);
			this->label8->MinimumSize = System::Drawing::Size(85, 50);
			this->label8->Name = L"label8";
			this->label8->Padding = System::Windows::Forms::Padding(6);
			this->label8->Size = System::Drawing::Size(85, 50);
			this->label8->TabIndex = 7;
			this->label8->Text = L"****";
			this->label8->Click += gcnew System::EventHandler(this, &game1::label8_Click);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::LightGray;
			this->label9->Cursor = System::Windows::Forms::Cursors::PanWest;
			this->label9->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label9->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(18, 147);
			this->label9->MaximumSize = System::Drawing::Size(85, 50);
			this->label9->MinimumSize = System::Drawing::Size(85, 50);
			this->label9->Name = L"label9";
			this->label9->Padding = System::Windows::Forms::Padding(6);
			this->label9->Size = System::Drawing::Size(85, 50);
			this->label9->TabIndex = 8;
			this->label9->Text = L"****";
			this->label9->Click += gcnew System::EventHandler(this, &game1::label9_Click);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->BackColor = System::Drawing::Color::LightGray;
			this->label10->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label10->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label10->Location = System::Drawing::Point(145, 147);
			this->label10->MaximumSize = System::Drawing::Size(85, 50);
			this->label10->MinimumSize = System::Drawing::Size(85, 50);
			this->label10->Name = L"label10";
			this->label10->Padding = System::Windows::Forms::Padding(6);
			this->label10->Size = System::Drawing::Size(85, 50);
			this->label10->TabIndex = 9;
			this->label10->Text = L"****";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->BackColor = System::Drawing::Color::LightGray;
			this->label11->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label11->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(272, 147);
			this->label11->MaximumSize = System::Drawing::Size(85, 50);
			this->label11->MinimumSize = System::Drawing::Size(85, 50);
			this->label11->Name = L"label11";
			this->label11->Padding = System::Windows::Forms::Padding(6);
			this->label11->Size = System::Drawing::Size(85, 50);
			this->label11->TabIndex = 10;
			this->label11->Text = L"****";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->BackColor = System::Drawing::Color::LightGray;
			this->label12->Cursor = System::Windows::Forms::Cursors::PanEast;
			this->label12->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label12->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label12->Location = System::Drawing::Point(399, 147);
			this->label12->MaximumSize = System::Drawing::Size(85, 50);
			this->label12->MinimumSize = System::Drawing::Size(85, 50);
			this->label12->Name = L"label12";
			this->label12->Padding = System::Windows::Forms::Padding(6);
			this->label12->Size = System::Drawing::Size(85, 50);
			this->label12->TabIndex = 11;
			this->label12->Text = L"****";
			this->label12->Click += gcnew System::EventHandler(this, &game1::label12_Click);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->BackColor = System::Drawing::Color::LightGray;
			this->label13->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label13->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label13->Location = System::Drawing::Point(18, 218);
			this->label13->MaximumSize = System::Drawing::Size(85, 50);
			this->label13->MinimumSize = System::Drawing::Size(85, 50);
			this->label13->Name = L"label13";
			this->label13->Padding = System::Windows::Forms::Padding(6);
			this->label13->Size = System::Drawing::Size(85, 50);
			this->label13->TabIndex = 12;
			this->label13->Text = L"****";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->BackColor = System::Drawing::Color::LightGray;
			this->label14->Cursor = System::Windows::Forms::Cursors::PanSouth;
			this->label14->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label14->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label14->Location = System::Drawing::Point(145, 218);
			this->label14->MaximumSize = System::Drawing::Size(85, 50);
			this->label14->MinimumSize = System::Drawing::Size(85, 50);
			this->label14->Name = L"label14";
			this->label14->Padding = System::Windows::Forms::Padding(6);
			this->label14->Size = System::Drawing::Size(85, 50);
			this->label14->TabIndex = 13;
			this->label14->Text = L"****";
			this->label14->Click += gcnew System::EventHandler(this, &game1::label14_Click);
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->BackColor = System::Drawing::Color::LightGray;
			this->label15->Cursor = System::Windows::Forms::Cursors::PanSouth;
			this->label15->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label15->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label15->Location = System::Drawing::Point(272, 218);
			this->label15->MaximumSize = System::Drawing::Size(85, 50);
			this->label15->MinimumSize = System::Drawing::Size(85, 50);
			this->label15->Name = L"label15";
			this->label15->Padding = System::Windows::Forms::Padding(6);
			this->label15->Size = System::Drawing::Size(85, 50);
			this->label15->TabIndex = 14;
			this->label15->Text = L"****";
			this->label15->Click += gcnew System::EventHandler(this, &game1::label15_Click);
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->BackColor = System::Drawing::Color::LightGray;
			this->label16->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->label16->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label16->Location = System::Drawing::Point(399, 218);
			this->label16->MaximumSize = System::Drawing::Size(85, 50);
			this->label16->MinimumSize = System::Drawing::Size(85, 50);
			this->label16->Name = L"label16";
			this->label16->Padding = System::Windows::Forms::Padding(6);
			this->label16->Size = System::Drawing::Size(85, 50);
			this->label16->TabIndex = 15;
			this->label16->Text = L"****";
			this->label16->Click += gcnew System::EventHandler(this, &game1::label16_Click);
			// 
			// button1
			// 
			this->button1->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button1->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->button1->Location = System::Drawing::Point(165, 279);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(163, 31);
			this->button1->TabIndex = 20;
			this->button1->Text = L"Quit";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &game1::button1_Click);
			// 
			// game1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSize = true;
			this->BackColor = System::Drawing::Color::DarkOliveGreen;
			this->ClientSize = System::Drawing::Size(493, 322);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label16);
			this->Controls->Add(this->label15);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->KeyPreview = true;
			this->Location = System::Drawing::Point(339, 287);
			this->MaximumSize = System::Drawing::Size(499, 351);
			this->MinimumSize = System::Drawing::Size(499, 351);
			this->Name = L"game1";
			this->Padding = System::Windows::Forms::Padding(5);
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L" ****2048****";
			this->Load += gcnew System::EventHandler(this, &game1::game1_Load);
			this->Activated += gcnew System::EventHandler(this, &game1::game1_Load);
			this->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &game1::keydown);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void game1_Load(System::Object^  sender, System::EventArgs^  e) {
			clear(a);
			new_val(a);
			display(a);
			 }
			 void left(){
		s_left(a);
        a_left(a);
        s_left(a);
        new_val(a);
		display(a);
		check();}
			 void right(){
				 s_right(a);
        a_right(a);
        s_right(a);
        new_val(a);
		display(a);
		check();
			 }
			 void up(){
				 s_up(a);
        a_up(a);
        s_up(a);
        new_val(a);
		display(a);
		check();
			 }
			 void down(){
				 s_down(a);
        a_down(a);
        s_down(a);
        new_val(a);
		display(a);
		check();
			 }
			 void display(int in_array[4][4]){
				 label1->Text = System::Convert::ToString(in_array[0][0]);
				 label2->Text = System::Convert::ToString(in_array[0][1]);
				 label3->Text = System::Convert::ToString(in_array[0][2]);
				 label4->Text = System::Convert::ToString(in_array[0][3]);
				 label5->Text = System::Convert::ToString(in_array[1][0]);
				 label6->Text = System::Convert::ToString(in_array[1][1]);
				 label7->Text = System::Convert::ToString(in_array[1][2]);
				 label8->Text = System::Convert::ToString(in_array[1][3]);
				 label9->Text = System::Convert::ToString(in_array[2][0]);
				 label10->Text = System::Convert::ToString(in_array[2][1]);
				 label11->Text = System::Convert::ToString(in_array[2][2]);
				 label12->Text = System::Convert::ToString(in_array[2][3]);
				 label13->Text = System::Convert::ToString(in_array[3][0]);
				 label14->Text = System::Convert::ToString(in_array[3][1]);
				 label15->Text = System::Convert::ToString(in_array[3][2]);
				 label16->Text = System::Convert::ToString(in_array[3][3]);
				}
			 void check()
			 {
				 if(win_check(a)){
					 win^ w=gcnew win;
					 w->ShowDialog();
					 Close();}
				 if(lose_check(a)){
					 lose^ l=gcnew lose;
					 l->ShowDialog();
					 Close();}
			 }
	private: System::Void label16_Click(System::Object^  sender, System::EventArgs^  e) {
				 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 Close();
		 }
private: System::Void label9_Click(System::Object^  sender, System::EventArgs^  e) {
			 left();
		 }
private: System::Void label5_Click(System::Object^  sender, System::EventArgs^  e) {
			 left();
		 }
private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
			 up();
		 }
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
			 up();
		 }
private: System::Void label8_Click(System::Object^  sender, System::EventArgs^  e) {
			 right();
		 }
private: System::Void label12_Click(System::Object^  sender, System::EventArgs^  e) {
			 right();
		 }
private: System::Void label15_Click(System::Object^  sender, System::EventArgs^  e) {
			 down();
		 }
private: System::Void label14_Click(System::Object^  sender, System::EventArgs^  e) {
			 down();
		 }

private: System::Void keydown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
			 if(e->KeyCode==Keys::Left){left();}
			 if(e->KeyCode==Keys::Up){up();}
			 if(e->KeyCode==Keys::Down){down();}
			 if(e->KeyCode==Keys::Right){right();}
		 }
};
}
